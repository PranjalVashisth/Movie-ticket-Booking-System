import http
from select import select
from flask import Flask, flash,render_template,request,session,redirect, url_for,flash
import flask
from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from jinja2 import select_autoescape
from werkzeug.security import generate_password_hash,check_password_hash
from flask_login import login_user,logout_user,login_manager,LoginManager
from flask_login import login_required,current_user

#My db connection
local_server=True
app = Flask(__name__)
app.secret_key='IshaAgrahari'

#this is for login purpose
login_manager=LoginManager(app)
login_manager.login_view='login'

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

#app.config['SQLALCHEMY_DATABASE_URI']='mysql://username:password@localhost/database_table_name'
app.config['SQLALCHEMY_DATABASE_URI']='mysql://root:@localhost/movie'
db=SQLAlchemy(app)

#here we will create db models that is tables
class Test(db.Model):
    id=db.Column(db.Integer,primary_key=True) 
    name=db.Column(db.String(100))
    email=db.Column(db.String(100))

class User(UserMixin,db.Model):
    id=db.Column(db.Integer,primary_key=True)
    username=db.Column(db.String(50))
    email=db.Column(db.String(50),unique=True)
    password=db.Column(db.String(1000))

class mybooking(db.Model):
    movie_id=db.Column(db.Integer,primary_key=True)
    email=db.Column(db.String(50),nullable=False)
    movie_name=db.Column(db.String(50))
    seat_type=db.Column(db.String(50))
    seat_number=db.Column(db.String(50))
    slots=db.Column(db.String(50))
    time=db.Column(db.String(50),nullable=False)
    date=db.Column(db.String(50),nullable=False)
    number=db.Column(db.String(50))

# here we will pass the endpoints and run the function
@app.route("/")
def index():
    return render_template('index.html')

@app.route("/movie")
def movie():
    return render_template('movie.html')  

@app.route("/mybookings",methods=['POST','GET'])
@login_required
def mybookings():
    if request.method=="POST":
        email=request.form.get('email')
        movie_name=request.form.get('movie_name')
        seat_type=request.form.get('seat_type')
        seat_number=request.form.get('seat_number')
        slots=request.form.get('slots')
        time=request.form.get('time')
        date=request.form.get('date')
        number=request.form.get('number')
        query=mybooking(email=email,movie_name=movie_name,seat_type=seat_type,seat_number=seat_number,slots=slots,time=time,date=date,number=number)
        db.session.add(query)
        db.session.commit()
        flash("Your Entertainment is Booked!","info")


    return render_template('mybookings.html')

@app.route("/bookingdetails")
@login_required
def bookingdetails():
    em=current_user.email
    query=mybooking.query.filter_by(email=em).first()
    return render_template('bookingdetails.html',query=query)

@app.route("/signup",methods=['POST','GET'])
def signup():
    if request.method == "POST":
        username=request.form.get('username')
        email=request.form.get('email')
        password=request.form.get('password')
        user=User.query.filter_by(email=email).first()
        if user:
            flask("Email Already Exists","warning")
            return render_template('/signup.html')
        encpassword=generate_password_hash(password)
        newuser=User(username=username,email=email,password=encpassword)
        db.session.add(newuser)
        db.session.commit()

        flash("Signup Success! Please Login!","success")
        return render_template('login.html')

    return render_template('signup.html')

@app.route("/login",methods=['POST','GET'])
def login():
    if request.method == "POST":
        email=request.form.get('email')
        password=request.form.get('password')
        user=User.query.filter_by(email=email).first()

        if user and check_password_hash(user.password,password):
            login_user(user)
            flash("Login Success","primary")
            return redirect(url_for('index'))
        else:
            flash("invalid credentials","danger")

    return render_template('login.html')

@app.route("/logout")
@login_required
def logout():
    logout_user()
    flash("Logout Successful","warning")
    return redirect(url_for('login'))


@app.route("/")
def hello_world():
    a=Test.query.all()
    print(a)
    return render_template('index.html')
    try:
         Test.query.all()
         return 'My database is connected'
    except:
         return 'My db is not Connected'

@app.route("/test")
def test():
    return render_template('test.html')

app.run(debug=True)